import React from 'react'
import { AuthGate } from '../AuthGate'
import { callDietRecommendations } from '../firebase'

export default function Diet() {
  const [species, setSpecies] = React.useState('perro')
  const [breed, setBreed] = React.useState('mestizo')
  const [age, setAge] = React.useState('3')
  const [text, setText] = React.useState('')

  async function go(e) {
    e.preventDefault()
    const { data } = await callDietRecommendations({ species, breed, age })
    setText(data.recommendations)
  }

  return (
    <AuthGate>
      <div>
        <h2>Recomendaciones de dieta</h2>
        <form onSubmit={go}>
          <label>Especie&nbsp;
            <select value={species} onChange={(e)=>setSpecies(e.target.value)}>
              <option value="perro">Perro</option>
              <option value="gato">Gato</option>
            </select>
          </label>
          &nbsp; Raza <input value={breed} onChange={(e)=>setBreed(e.target.value)} />
          &nbsp; Edad (años) <input type="number" value={age} onChange={(e)=>setAge(e.target.value)} />
          &nbsp; <button>Generar</button>
        </form>
        {text && (<div><h3>Resultado</h3><pre style={{whiteSpace:'pre-wrap'}}>{text}</pre></div>)}
      </div>
    </AuthGate>
  )
}