import React from 'react'
import { AuthGate } from '../AuthGate'

export default function Dashboard() {
  return (
    <AuthGate>
      <div>
        <h2>Panel del tutor</h2>
        <p>Aquí irá el perfil de mascota, documentos, vacunas, etc.</p>
      </div>
    </AuthGate>
  )
}