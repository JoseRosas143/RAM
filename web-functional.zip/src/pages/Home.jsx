import React from 'react'
import { Link } from 'react-router-dom'
import { pingHealth } from '../api'

export default function Home() {
  const [ok, setOk] = React.useState(null)
  React.useEffect(() => { pingHealth().then(setOk).catch(() => setOk(false)) }, [])
  return (
    <div>
      <h1>Registro Animal MX</h1>
      <p>Health: {ok === null ? '...' : ok ? 'OK' : 'Error'}</p>
      <ul>
        <li><Link to="/dashboard">Ir al panel</Link></li>
        <li><Link to="/premium">Premium</Link></li>
        <li><Link to="/vet">Vet IA</Link></li>
        <li><Link to="/diet">Recomendaciones de dieta</Link></li>
        <li><Link to="/lost">Reportar extravío</Link></li>
        <li><Link to="/pet/demo123">Vista pública de mascota (demo)</Link></li>
      </ul>
    </div>
  )
}