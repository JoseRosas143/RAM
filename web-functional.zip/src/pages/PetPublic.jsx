import React from 'react'
import { useParams } from 'react-router-dom'
import { db } from '../firebase'
import { doc, getDoc } from 'firebase/firestore'

export default function PetPublic() {
  const { id } = useParams()
  const [pet, setPet] = React.useState(null)
  const [err, setErr] = React.useState('')
  React.useEffect(() => {
    (async () => {
      try {
        const snap = await getDoc(doc(db, 'pets', id))
        if (!snap.exists()) setErr('No encontrada')
        else setPet(snap.data())
      } catch (e) { setErr(String(e)) }
    })()
  }, [id])

  if (err) return <p>Error: {err}</p>
  if (!pet) return <p>Cargando…</p>
  return (
    <div>
      <h2>{pet.name}</h2>
      <p><b>Microchip:</b> {pet.microchip || '—'}</p>
      <p><b>Especie:</b> {pet.species} • <b>Raza:</b> {pet.breed}</p>
      <p><b>Edad:</b> {pet.age} años</p>
    </div>
  )
}