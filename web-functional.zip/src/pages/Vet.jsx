import React from 'react'
import { AuthGate } from '../AuthGate'
import { callVetChat } from '../firebase'

export default function Vet() {
  const [msg, setMsg] = React.useState('')
  const [ans, setAns] = React.useState('')

  async function ask(e) {
    e.preventDefault()
    const { data } = await callVetChat({ message: msg })
    setAns(data.reply)
  }

  return (
    <AuthGate>
      <div>
        <h2>Veterinario IA</h2>
        <form onSubmit={ask}>
          <textarea value={msg} onChange={(e)=>setMsg(e.target.value)} rows={4} style={{width:'100%'}} />
          <br/><button>Preguntar</button>
        </form>
        {ans && (<div><h3>Respuesta</h3><pre style={{whiteSpace:'pre-wrap'}}>{ans}</pre></div>)}
      </div>
    </AuthGate>
  )
}