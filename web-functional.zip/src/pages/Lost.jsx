import React from 'react'
import { AuthGate } from '../AuthGate'
import { notifyLost } from '../api'

export default function Lost() {
  const [chip, setChip] = React.useState('')
  const [res, setRes] = React.useState(null)
  async function go(e) {
    e.preventDefault()
    const r = await notifyLost(chip)
    setRes(r)
  }
  return (
    <AuthGate>
      <div>
        <h2>Reportar extravío</h2>
        <form onSubmit={go}>
          Microchip:&nbsp;
          <input value={chip} onChange={(e)=>setChip(e.target.value)} />
          &nbsp;<button>Reportar</button>
        </form>
        {res && <pre>{JSON.stringify(res, null, 2)}</pre>}
      </div>
    </AuthGate>
  )
}