import React from 'react'
import CheckoutButton from '../components/CheckoutButton'
import { AuthGate } from '../AuthGate'

export default function Premium() {
  const priceId = import.meta.env.VITE_STRIPE_PREMIUM_PRICE_ID
  const qs = new URLSearchParams(location.search)
  const status = qs.get('status')
  return (
    <AuthGate>
      <div>
        <h2>Premium</h2>
        {status === 'success' && <p>✅ ¡Pago completado!</p>}
        {status === 'cancel' && <p>❌ Pago cancelado.</p>}
        <p>Acceso al chatbot veterinario y recomendaciones personalizadas.</p>
        <CheckoutButton priceId={priceId} mode="subscription" />
      </div>
    </AuthGate>
  )
}