import React from 'react'
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth'
import { auth } from './firebase'

export function AuthGate({ children }) {
  const [user, setUser] = React.useState()
  const [loading, setLoading] = React.useState(true)
  React.useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); setLoading(false) }), [])
  if (loading) return <p>Cargando sesión…</p>
  if (!user) return (
    <div style={{ padding: 24 }}>
      <h2>Inicia sesión</h2>
      <button onClick={() => signInWithPopup(auth, new GoogleAuthProvider())}>Entrar con Google</button>
    </div>
  )
  return (
    <div>
      <div style={{ padding: 8, fontSize: 12 }}>
        Sesión: {user.email} <button onClick={() => signOut(auth)}>Salir</button>
      </div>
      {children}
    </div>
  )
}