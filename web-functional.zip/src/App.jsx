import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Premium from './pages/Premium.jsx'
import Vet from './pages/Vet.jsx'
import Diet from './pages/Diet.jsx'
import Lost from './pages/Lost.jsx'
import PetPublic from './pages/PetPublic.jsx'

export default function App() {
  return (
    <BrowserRouter>
      <header>
        <nav className="container">
          <Link to="/">Inicio</Link>
          <Link to="/dashboard">Panel</Link>
          <Link to="/premium">Premium</Link>
          <Link to="/vet">Vet IA</Link>
          <Link to="/diet">Dieta</Link>
          <Link to="/lost">Extravío</Link>
        </nav>
      </header>
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/premium" element={<Premium />} />
          <Route path="/vet" element={<Vet />} />
          <Route path="/diet" element={<Diet />} />
          <Route path="/lost" element={<Lost />} />
          <Route path="/pet/:id" element={<PetPublic />} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}