import { auth } from './firebase'
const BASE = 'https://us-central1-registro-animal-mx.cloudfunctions.net'

async function authedFetch(path, opts = {}) {
  const token = await auth.currentUser?.getIdToken?.()
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) }
  if (token) headers.Authorization = `Bearer ${token}`
  const res = await fetch(`${BASE}/${path}`, { ...opts, headers })
  if (!res.ok) throw new Error(await res.text())
  return res.json()
}

export function notifyLost(microchip) {
  return authedFetch('notifyLost', {
    method: 'POST',
    body: JSON.stringify({ microchip }),
  })
}

export async function pingHealth() {
  const res = await fetch(`${BASE}/health`)
  return res.ok
}